/**
 * PKM / n8n Externalized Code Node
 *
 * Workflow: Read (read)
 * Node: Build SQL - /CONTINUE
 * Node ID: 138ce96f-f56c-4bea-9443-67686bd6066b
 *
 * Notes:
 * - Generated from workflow export for clean Git diffs.
 * - Keep return shape identical to original Code node.
 * - Sandbox: require() allowed (allowlisted); fs/process not available.
 */
'use strict';

module.exports = async function run(ctx) {
  const { $input, $json, $items, $node, $env, helpers } = ctx;


  // --- DB schema routing (prod vs test) ---
  // Default: production schema ("pkm"). Enable test mode by setting:
  //   $json.config.db.is_test_mode = true
  // Optionally override schema names:
  //   $json.config.db.schema_prod = "pkm"
  //   $json.config.db.schema_test = "pkm_test"
  const config = ($json && $json.config) ? $json.config : {};
  const db = (config && config.db) ? config.db : {};

  const is_test_mode = !!db.is_test_mode;
  const schema_prod = db.schema_prod || 'pkm';
  const schema_test = db.schema_test || 'pkm_test';
  const schema_candidate = is_test_mode ? schema_test : schema_prod;

  const isValidIdent = (s) => (typeof s === 'string') && /^[a-zA-Z_][a-zA-Z0-9_]*$/.test(s);
  const db_schema = isValidIdent(schema_candidate) ? schema_candidate : 'pkm';

  // Safe, quoted identifier reference for SQL templates
  const entries_table = `"${db_schema}"."entries"`;
function sqlString(v) {
  if (v === null || v === undefined) return 'NULL';
  const s = String(v).replace(/'/g, "''");
  return `'${s}'`;
}

const q = String($json.q || '').trim();
const days = Number($json.days || 90);

const cfgLimit = Number($json.config?.scoring?.maxItems?.continue || 15);
const limit = Math.min(cfgLimit, Math.max(1, Number($json.limit || 10)));

const W = $json.config?.scoring?.weightsByCmd?.continue || {};
const halfLife = Number($json.config?.scoring?.recencyByCmd?.continue?.half_life_days || 45);
const noteQuota = Number($json.config?.scoring?.noteQuotaByCmd?.continue || 0.75);

const sql = `
WITH params AS (
  SELECT
    ${sqlString(q)}::text AS qtext,
    websearch_to_tsquery('english', ${sqlString(q)}) AS tsq,
    ${days}::int AS days,
    ${limit}::int AS lim,
    ${halfLife}::real AS half_life_days,
    ${noteQuota}::real AS note_quota
),

base AS (
  SELECT
    e.entry_id,
    e.id,
    e.created_at,
    e.source,
    e.intent,
    e.content_type,
    COALESCE(e.url_canonical, e.url, '') AS url,
    COALESCE(e.title, e.external_ref->>'title', '') AS title,
    COALESCE(e.author, '') AS author,

    COALESCE(e.topic_primary,'') AS topic_primary,
    COALESCE(e.topic_secondary,'') AS topic_secondary,
    COALESCE(e.gist,'') AS gist,
    COALESCE(e.retrieval_excerpt, e.metadata #>> '{retrieval,excerpt}', '') AS excerpt,

    COALESCE(e.keywords, ARRAY[]::text[]) AS keywords,
    COALESCE(e.quality_score, 0.5) AS quality_score,
    COALESCE(e.boilerplate_heavy, false) AS boilerplate_heavy,
    COALESCE(e.low_signal, false) AS low_signal,
    COALESCE(e.extraction_incomplete, false) AS extraction_incomplete,
    COALESCE(e.link_ratio, 0.0) AS link_ratio,

    p.qtext,
    p.tsq,

    exp( - (extract(epoch from (now() - e.created_at)) / 86400.0) / p.half_life_days ) AS recency,

    to_tsvector('english',
      trim(
        COALESCE(e.topic_primary,'') || ' ' ||
        COALESCE(e.topic_secondary,'') || ' ' ||
        COALESCE(array_to_string(e.keywords,' '),'') || ' ' ||
        COALESCE(e.gist,'') || ' ' ||
        COALESCE(e.title,'') || ' ' ||
        COALESCE(e.author,'')
      )
    ) AS t1_tsv
  FROM ${entries_table} e, params p
  WHERE
    e.created_at >= (now() - (p.days || ' days')::interval)
    AND e.duplicate_of IS NULL
),

scored AS (
  SELECT
    b.*,
    ts_rank_cd(b.t1_tsv, b.tsq) AS t1_rank,
    ts_rank_cd(e.tsv, b.tsq) AS fts_rank,

    (
      (CASE WHEN lower(b.topic_primary) = lower(b.qtext) THEN ${Number(W.topic_primary_exact || 0)} ELSE 0 END) +
      (CASE WHEN lower(b.topic_primary) LIKE lower(b.qtext) || '%' THEN ${Number(W.topic_primary_fuzzy || 0)} ELSE 0 END) +
      (CASE WHEN lower(b.topic_secondary) = lower(b.qtext) THEN ${Number(W.topic_secondary_exact || 0)} ELSE 0 END) +
      (CASE WHEN lower(b.topic_secondary) LIKE '%' || lower(b.qtext) || '%' THEN ${Number(W.topic_secondary_fuzzy || 0)} ELSE 0 END) +

      -- keywords overlap (fixed)
      LEAST(
        ${Number(W.keywords_overlap_cap || 0)},
        ${Number(W.keywords_overlap_each || 0)} * (
          SELECT count(*)
          FROM unnest(b.keywords) kw
          WHERE kw <> ''
            AND lower(kw) = ANY (regexp_split_to_array(lower(b.qtext), '\\s+'))
        )
      ) +

      (CASE WHEN b.gist ILIKE '%' || b.qtext || '%' THEN ${Number(W.gist_match || 0)} ELSE 0 END) +
      (CASE WHEN b.title ILIKE '%' || b.qtext || '%' THEN ${Number(W.title_match || 0)} ELSE 0 END) +
      (CASE WHEN b.author ILIKE '%' || b.qtext || '%' THEN ${Number(W.author_match || 0)} ELSE 0 END) +

      (${Number(W.fts_rank || 0)} * ts_rank_cd(e.tsv, b.tsq)) +

      (CASE WHEN b.content_type = 'note' THEN ${Number(W.prefer_content_type_note || 0)} ELSE 0 END) +
      (CASE WHEN b.intent = 'think' THEN ${Number(W.prefer_intent_think || 0)} ELSE 0 END) +
      (CASE WHEN b.topic_primary <> '' THEN ${Number(W.prefer_enriched || 0)} ELSE 0 END) +

      (10.0 * b.quality_score) +
      (5.0 * b.recency) -

      (CASE WHEN b.boilerplate_heavy THEN ${Number(W.penalty_boilerplate_heavy || 0)} ELSE 0 END) -
      (CASE WHEN b.low_signal THEN ${Number(W.penalty_low_signal || 0)} ELSE 0 END) -
      (CASE WHEN b.link_ratio > 0.18 THEN ${Number(W.penalty_link_ratio_high || 0)} ELSE 0 END) -
      (CASE WHEN b.extraction_incomplete THEN ${Number(W.penalty_extraction_incomplete || 0)} ELSE 0 END)
    ) AS score
  FROM base b
  JOIN ${entries_table} e ON e.id = b.id
  WHERE
    b.tsq IS NOT NULL
    AND (e.tsv @@ b.tsq OR b.t1_tsv @@ b.tsq OR lower(b.topic_primary) = lower(b.qtext))
),

notes AS (
  SELECT *, row_number() OVER (ORDER BY score DESC, created_at DESC) AS rn
  FROM scored
  WHERE content_type = 'note'
),
externals AS (
  SELECT *, row_number() OVER (ORDER BY score DESC, created_at DESC) AS rn
  FROM scored
  WHERE content_type IS DISTINCT FROM 'note'
),

/* FIX: only select the hit rows (notes/externals), not params/note_count columns */
note_pick AS (
  SELECT n.*
  FROM notes n
  CROSS JOIN params p
  WHERE n.rn <= greatest(1, floor(p.lim * p.note_quota))::int
),
note_count AS (
  SELECT count(*)::int AS n FROM note_pick
),
external_pick AS (
  SELECT x.*
  FROM externals x
  CROSS JOIN params p
  CROSS JOIN note_count nc
  WHERE x.rn <= (p.lim - nc.n)
),
hits AS (
  SELECT * FROM note_pick
  UNION ALL
  SELECT * FROM external_pick
),

meta_row AS (
  SELECT
    TRUE AS is_meta,
    'continue'::text AS cmd,
    p.qtext AS query_text,
    p.days AS days,
    p.lim AS limit,
    (SELECT count(*) FROM hits)::int AS hits,
    NULL::bigint AS entry_id,
    NULL::uuid AS id,
    NULL::timestamptz AS created_at,
    NULL::text AS source,
    NULL::text AS intent,
    NULL::text AS content_type,
    NULL::text AS url,
    NULL::text AS title,
    NULL::text AS author,
    NULL::text AS topic_primary,
    NULL::text AS topic_secondary,
    NULL::text AS gist,
    NULL::text AS excerpt,
    NULL::double precision AS score,
    NULL::text AS snippet
  FROM params p
),

hit_rows AS (
  SELECT
    FALSE AS is_meta,
    'continue'::text AS cmd,
    (SELECT qtext FROM params) AS query_text,
    (SELECT days FROM params) AS days,
    (SELECT lim FROM params) AS limit,
    NULL::int AS hits,
    h.entry_id,
    h.id,
    h.created_at,
    h.source,
    h.intent,
    h.content_type,
    h.url,
    h.title,
    h.author,
    h.topic_primary,
    h.topic_secondary,
    h.gist,
    h.excerpt,
    h.score::double precision AS score,
    NULL::text AS snippet
  FROM hits h
),

out AS (
  SELECT * FROM meta_row
  UNION ALL
  SELECT * FROM hit_rows
)

SELECT *
FROM out
ORDER BY is_meta DESC, score DESC NULLS LAST, created_at DESC NULLS LAST;
`.trim();

return [{ json: { ...$json, sql } }];
};
