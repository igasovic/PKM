/**
 * Shared SQL helpers for PKM n8n SQL builders
 * - esc: escape single quotes + backslashes for safe SQL string literals
 * - lit: wrap as SQL string literal or NULL
 *
 * NOTE: This is not perfect SQL injection protection, but it is the minimum
 * sane standard when the DB node cannot accept parameters.
 */
'use strict';

function esc(s) {
  return String(s).replace(/\\/g, '\\\\').replace(/'/g, "''");
}

function lit(v) {
  return (v === null || v === undefined) ? 'NULL' : `'${esc(v)}'`;
}

module.exports = { esc, lit };
